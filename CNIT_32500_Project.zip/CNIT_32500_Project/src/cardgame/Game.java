package cardgame;

/*
* Cassie Kim
* Xiaotong Luo
* Sean Maloney
* Emily Zhang
*/

import java.util.*;

public abstract class Game implements Deck {
    // Define attributes.
    ArrayList<Card> deck = new ArrayList();
    
    public Card topCard;
    public int dealCount;
    
    // Getters.
    public Card getTopCard() {
        return topCard;
    }
    
    public int getDealCount() {
        return dealCount;
    }
    
    // Setters.
    public void setTopCard(Card input) {
        this.topCard = input;
    }
    
    public void setDealCount(int input) {
        this.dealCount = input;
    }
    
    // Build the deck. Overwritten by children.
    public void buildDeck() {
        
    } // End public void buildDeck.
    
    // Shuffle the deck. From the Deck interface.
    public void shuffleCards() {
        Collections.shuffle(deck);
    } // End public void shuffleCards.
    
    // Deal from the deck. From the Deck interface.
    public void dealCards(Player player, int dealCount) {
        for(int i = 0; i < dealCount; i++) {
            player.draw(deck.get(i));
        }
    } // End publuc void dealCards.
} // End public class Game.