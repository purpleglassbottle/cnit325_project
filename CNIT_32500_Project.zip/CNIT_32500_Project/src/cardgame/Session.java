package cardgame;

/*
* Cassie Kim
* Xiaotong Luo
* Sean Maloney
* Emily Zhang
*/

import java.util.*;

public class Session {
    // Define attributes.
    ArrayList<Player> players = new ArrayList();
        
    public Player currentPlayer;
    Player player0 = new Player(0, "Sean");
    
    public Game game;
    
    // Begine the game.
    public void startGame() {
        game = new GameTest();
        game.setDealCount(5);
        
        game.buildDeck();
        game.shuffleCards();
        game.dealCards(player0, game.getDealCount());
        
        player0.showHand();
    } // End public void startGame.
    
    // Main function.
    public static void main(String[] args) {
        Session session = new Session();
        
        session.startGame();
    } // End public static void main.
} // End public class Session.